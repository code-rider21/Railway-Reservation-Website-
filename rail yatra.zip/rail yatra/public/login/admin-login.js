// Get the form and button elements
const form = document.getElementById('AdminauthForm');
const signBtn = document.getElementById('signBtn');

// Add an event listener to the button
signBtn.addEventListener('click', async (e) => {
  e.preventDefault();

  // Get the form data
  const name = document.querySelector('input[name="name"]').value;
  const email = document.querySelector('input[name="email"]').value;
  const password = document.querySelector('input[name="password"]').value;

  // Create a JSON object to send to the server
  const formData = {
    name,
    email,
    password,
  };

  // Send a POST request to the server
  try {
    const response = await fetch('/admin/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData),
    });

    // Check if the response was successful
    if (response.ok) {
      const token = await response.json();
      // Store the token in local storage
      localStorage.setItem('adminToken', token);
      // Redirect to the admin dashboard
      window.location.href = '/admin/dashboard';
    } else {
      alert('Invalid credentials');
    }
  } catch (error) {
    console.error(error);
    alert('Error logging in');
  }
});