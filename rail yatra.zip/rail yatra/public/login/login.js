document.addEventListener('DOMContentLoaded', () => {
    let signUpBtn = document.getElementById("signUpBtn");
    let signInBtn = document.getElementById("signInBtn");
    let nameField = document.getElementById("nameField");
    let title = document.getElementById("title");
    let registerBtn = document.getElementById("addSignUpdata");
    let authForm = document.getElementById("authForm");
    

    signInBtn.onclick = function() {
        nameField.style.maxHeight = "0";
        title.innerHTML = "Sign In";
        signUpBtn.classList.add("disabled");
        signInBtn.classList.remove("disabled");
        registerBtn.textContent = "Sign In";
    };

    signUpBtn.onclick = function() {
        nameField.style.maxHeight = "60px";
        title.innerHTML = "Sign Up";
        signUpBtn.classList.remove("disabled");
        signInBtn.classList.add("disabled");
        registerBtn.textContent = "Register";
    };

    registerBtn.addEventListener('click', function(event) {
        event.preventDefault();
        console.log("Register button clicked");
        const name = document.querySelector('input[placeholder="Name"]').value;
        const email = document.querySelector('input[placeholder="Email"]').value;
        const password = document.querySelector('input[placeholder="Password"]').value;

        const url = title.innerHTML == "Sign Up" ? 'http://localhost:8080/signup' : 'http://localhost:8080/signin';
        const body = title.innerHTML == "Sign Up" ? { name, email, password } : { email, password };

        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body),
        })
        .then(response => response.json())
        .then(data => {
            console.log('Success:', data);
            if (title.innerHTML == "Sign In" && data.token) {
                // Handle successful sign-in
                console.log("Signed in successfully");
                window.location.href = 'user.html';
            } else if (title.innerHTML == "Sign Up" && data.msg == "success") {
                // Handle successful sign-up
                console.log("Registered successfully");
                alert("Registration successful! Please sign in.");
                signInBtn.onclick();
            } else {
                alert(data.msg);
            }
            })
        .catch((error) => {
            console.error('Error:', error);
        });
    });
    authForm.addEventListener('submit', function(event) {
        event.preventDefault();
    });
});


