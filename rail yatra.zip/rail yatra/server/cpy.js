const mongoose = require('mongoose');
const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
require('dotenv').config();

const app = express();

app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("Database connected"))
  .catch(err => console.log(err));

const User = require('./models/User');
const Admin = require('./models/Admin');
const { verifyAdmin, verifyToken } = require('./middlewares/auth');

app.post("/signup", async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ msg: "All fields are required." });
  }
  try {
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ msg: "User already exists." });
    }
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    user = new User({ name, email, password: hashedPassword });
    await user.save();
    return res.status(201).json({ msg: "User registered successfully." });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ msg: "Internal server error." });
  }
});

app.post("/signin", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ msg: "All fields are required." });
  }
  try {
    let user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ msg: "Invalid Credentials." });
    }
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ msg: "Invalid Credentials." });
    }
    const payload = { user: { id: user.id } };
    jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' }, (err, token) => {
      if (err) throw err;
      res.json({ token });
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send('Server error');
  }
});

app.post('/admin/login', verifyAdmin, (req, res) => {
  const payload = { admin: { id: req.admin.id, role: req.admin.role } };
  jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' }, (err, token) => {
    if (err) throw err;
    res.json({ token });
  });
});

app.use('/admin', verifyToken, (req, res, next) => {
  if (req.admin && req.admin.role === 'admin') {
    next();
  } else {
    res.status(403).json({ msg: 'Forbidden' });
  }
});

app.get('/admin/dashboard', (req, res) => {
  res.sendFile(__dirname + '/public/adminPage.html');
});

app.listen(8080, () => console.log('Server started at port 8080'));

// Create a single admin account
async function createAdmin() {
  const adminData = {
    name: 'Brutitapa_21',
    email: 'brutitapa_mishra@gmail.com',
    password: 'Bruti@123',
  };

  try {
    const admin = await Admin.findOne({ email: adminData.email });
    if (!admin) {
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(adminData.password, salt);
      const newAdmin = new Admin({ ...adminData, password: hashedPassword });
      await newAdmin.save();
      console.log("Admin account created.");
    } else {
      console.log(`Admin account with email ${adminData.email} already exists.`);
    }
  } catch (error) {
    console.error(error);
  }
}

createAdmin();
